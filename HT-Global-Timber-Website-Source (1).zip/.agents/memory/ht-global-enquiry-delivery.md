---
name: HT Global enquiry delivery
description: Durable rules for the HT Global timber site's contact details, enquiry delivery, and map handling.
---

Use only contact details explicitly verified by HT Global. Website quotation enquiries should be delivered through the connected transactional email provider rather than relying on a browser-only confirmation.

**Why:** The original public reference did not publish reliable phone or email details, and inventing them would misdirect B2B enquiries. The site needs a real sales destination to be production-ready.

**How to apply:** Keep the verified sales email, phone/WhatsApp number, and map link aligned across contact surfaces and enquiry notifications. Use a stable place/search URL for embedded maps; retain the exact short map link as the user-facing external map action.