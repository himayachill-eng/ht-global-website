import { Router, type IRouter } from "express";
import { ReplitConnectors } from "@replit/connectors-sdk";
import {
  SubmitEnquiryBody,
  SubmitEnquiryResponse,
  type EnquiryInput,
} from "@workspace/api-zod";

const router: IRouter = Router();
const salesEmail = "htglobal.traders@gmail.com";
const fromEmail =
  process.env["RESEND_FROM_EMAIL"] ?? "HT Global Website <onboarding@resend.dev>";

function escapeHtml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function buildEmailHtml(input: EnquiryInput) {
  const itemRows = input.items
    .map(
      (item) => `
        <tr>
          <td style="padding:8px 12px;border:1px solid #d9ded4">${escapeHtml(item.productName)}</td>
          <td style="padding:8px 12px;border:1px solid #d9ded4">${item.quantity}</td>
          <td style="padding:8px 12px;border:1px solid #d9ded4">${escapeHtml(item.unit)}</td>
        </tr>`,
    )
    .join("");

  const field = (label: string, value: unknown) =>
    `<p><strong>${label}:</strong> ${escapeHtml(String(value ?? "") || "Not provided")}</p>`;

  return `
    <div style="font-family:Arial,sans-serif;color:#183f31;line-height:1.5">
      <h1 style="font-size:24px">New HT Global quotation enquiry</h1>
      ${field("Name", input.name)}
      ${field("Company", input.company)}
      ${field("Email", input.email)}
      ${field("Phone / WhatsApp", input.phone)}
      ${field("Country", input.country)}
      ${field("Delivery location / port", input.destination)}
      ${field("Preferred delivery date", input.deliveryDate ?? "Not specified")}
      <h2 style="font-size:18px;margin-top:28px">Requested products</h2>
      <table style="border-collapse:collapse;width:100%">
        <thead><tr>
          <th style="text-align:left;padding:8px 12px;border:1px solid #d9ded4">Product</th>
          <th style="text-align:left;padding:8px 12px;border:1px solid #d9ded4">Quantity</th>
          <th style="text-align:left;padding:8px 12px;border:1px solid #d9ded4">Unit</th>
        </tr></thead>
        <tbody>${itemRows}</tbody>
      </table>
      ${field("Product requirements", input.requirements)}
      ${field("Additional requirements", input.notes)}
      <p style="font-size:12px;color:#607066;margin-top:28px">Consent to contact: ${input.consent ? "Yes" : "No"}</p>
    </div>`;
}

router.post("/enquiries", async (req, res): Promise<void> => {
  const parsed = SubmitEnquiryBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.flatten() }, "Invalid quotation enquiry");
    res.status(400).json({ error: "Please complete all required enquiry fields." });
    return;
  }

  if (!parsed.data.consent) {
    res.status(400).json({ error: "Consent is required before submitting an enquiry." });
    return;
  }

  const subject = `Quotation enquiry from ${parsed.data.company}`;
  const connectors = new ReplitConnectors();

  try {
    const response = await connectors.proxy("resend", "/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        from: fromEmail,
        to: [salesEmail],
        reply_to: parsed.data.email,
        subject,
        html: buildEmailHtml(parsed.data),
      }),
    });

    if (!response.ok) {
      const details = await response.text();
      req.log.error(
        { status: response.status, details },
        "Resend rejected quotation enquiry",
      );
      res.status(502).json({ error: "The sales desk could not receive the enquiry." });
      return;
    }

    req.log.info({ company: parsed.data.company }, "Quotation enquiry delivered");
    res.json(
      SubmitEnquiryResponse.parse({
        status: "sent",
        message: "Your enquiry was sent to the HT Global sales desk.",
      }),
    );
  } catch (error) {
    req.log.error({ err: error }, "Quotation enquiry delivery failed");
    res.status(502).json({ error: "The sales desk could not receive the enquiry." });
  }
});

export default router;