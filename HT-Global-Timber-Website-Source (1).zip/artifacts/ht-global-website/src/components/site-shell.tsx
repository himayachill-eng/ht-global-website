import { useEffect, useMemo, useState, createContext, useContext, type ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { ArrowUpRight, Menu, Minus, Plus, X } from 'lucide-react';
import { products, navItems, type Product } from '@/lib/site-data';

type EnquiryItem = { productId: string; quantity: number; unit: string };
type EnquiryContextValue = {
  items: EnquiryItem[];
  addItem: (product: Product, quantity: number, unit: string) => void;
  updateItem: (productId: string, quantity: number, unit: string) => void;
  removeItem: (productId: string) => void;
  clearItems: () => void;
  itemCount: number;
};

const EnquiryContext = createContext<EnquiryContextValue | null>(null);

export function EnquiryProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<EnquiryItem[]>(() => {
    try { return JSON.parse(localStorage.getItem('ht-global-enquiry') || '[]') as EnquiryItem[]; } catch { return []; }
  });
  useEffect(() => { localStorage.setItem('ht-global-enquiry', JSON.stringify(items)); }, [items]);
  const value = useMemo(() => ({
    items,
    addItem: (product: Product, quantity: number, unit: string) => setItems((current) => {
      const found = current.find((item) => item.productId === product.id);
      if (found) return current.map((item) => item.productId === product.id ? { ...item, quantity: item.quantity + quantity, unit } : item);
      return [...current, { productId: product.id, quantity, unit }];
    }),
    updateItem: (productId: string, quantity: number, unit: string) => setItems((current) => current.map((item) => item.productId === productId ? { ...item, quantity, unit } : item)),
    removeItem: (productId: string) => setItems((current) => current.filter((item) => item.productId !== productId)),
    clearItems: () => setItems([]),
    itemCount: items.reduce((sum, item) => sum + item.quantity, 0),
  }), [items]);
  return <EnquiryContext.Provider value={value}>{children}</EnquiryContext.Provider>;
}

export function useEnquiry() {
  const context = useContext(EnquiryContext);
  if (!context) throw new Error('useEnquiry must be used within EnquiryProvider');
  return context;
}

export function Header() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const { itemCount } = useEnquiry();
  useEffect(() => { setOpen(false); }, [location]);
  return (
    <>
      <div className="bg-primary text-primary-foreground px-5 py-2.5 text-center text-[11px] tracking-[0.12em] uppercase">
        Malaysian timber, plywood & veneer · Built for international supply
      </div>
      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/95 backdrop-blur-md">
        <div className="mx-auto flex h-[76px] max-w-[1400px] items-center justify-between px-5 md:px-8 lg:px-12">
          <Link href="/" className="group flex items-center gap-3" data-testid="link-logo">
            <span className="grid h-10 w-10 place-items-center border border-primary text-primary">
              <span className="display-font text-2xl leading-none">HT</span>
            </span>
            <span className="hidden sm:block">
              <span className="block text-[13px] font-semibold tracking-[0.18em] text-primary">HT GLOBAL</span>
              <span className="mono-font block text-[8px] tracking-[0.2em] text-muted-foreground">IMPORT · EXPORT</span>
            </span>
          </Link>
          <nav className="hidden items-center gap-5 lg:flex">
            {navItems.map((item) => <Link key={item.href} href={item.href} data-testid={`link-nav-${item.label.toLowerCase()}`} className={`text-[13px] transition-colors hover:text-primary ${location === item.href ? 'text-primary font-semibold' : 'text-muted-foreground'}`}>{item.label}</Link>)}
          </nav>
          <div className="flex items-center gap-3">
            <Link href="/enquiry-cart" data-testid="link-enquiry-header" className="group flex items-center gap-2 border border-border px-3 py-2 text-[12px] font-semibold text-foreground transition-colors hover:border-primary hover:text-primary">
              <span className="hidden sm:inline">Enquiry list</span><span className="mono-font grid h-5 min-w-5 place-items-center bg-secondary px-1 text-[10px]">{itemCount}</span>
            </Link>
            <Link href="/contact" data-testid="link-contact-header" className="hidden bg-accent px-4 py-2.5 text-[12px] font-semibold text-accent-foreground transition-transform hover:-translate-y-0.5 md:flex">Speak with our team <ArrowUpRight size={14} /></Link>
            <button type="button" data-testid="button-toggle-menu" aria-label={open ? 'Close navigation' : 'Open navigation'} onClick={() => setOpen((value) => !value)} className="grid h-10 w-10 place-items-center border border-border lg:hidden">{open ? <X size={18} /> : <Menu size={18} />}</button>
          </div>
        </div>
        {open && <div className="border-t border-border bg-background px-5 py-5 lg:hidden">
          <nav className="grid gap-1">
            {navItems.map((item) => <Link key={item.href} href={item.href} data-testid={`link-mobile-${item.label.toLowerCase()}`} className="border-b border-border py-3 text-base">{item.label}</Link>)}
          </nav>
          <Link href="/contact" data-testid="link-mobile-contact" className="mt-5 flex items-center justify-between bg-primary px-4 py-3 text-sm text-primary-foreground">Start a conversation <ArrowUpRight size={16} /></Link>
        </div>}
      </header>
    </>
  );
}

export function Footer() {
  return <footer className="bg-primary text-primary-foreground">
    <div className="mx-auto grid max-w-[1400px] gap-12 px-5 py-16 md:grid-cols-12 md:px-8 lg:px-12 lg:py-20">
      <div className="md:col-span-5">
        <div className="mb-6 flex items-center gap-3"><span className="grid h-10 w-10 place-items-center border border-primary-foreground/50"><span className="display-font text-2xl">HT</span></span><span className="text-[13px] font-semibold tracking-[0.18em]">HT GLOBAL</span></div>
        <p className="max-w-sm text-sm leading-7 text-primary-foreground/70">A Malaysia-based import export partner for timber and wood products, connecting reliable supply with the standards of international buyers.</p>
      </div>
      <div className="md:col-span-3"><p className="eyebrow mb-5 text-primary-foreground/50">Explore</p><div className="grid gap-3 text-sm text-primary-foreground/80">{navItems.map((item) => <Link key={item.href} href={item.href} data-testid={`link-footer-${item.label.toLowerCase()}`} className="transition-colors hover:text-accent">{item.label}</Link>)}</div></div>
      <div className="md:col-span-4"><p className="eyebrow mb-5 text-primary-foreground/50">Trade desk</p><p className="text-sm leading-7 text-primary-foreground/80">Penang<br />Malaysia</p><Link href="/contact" data-testid="link-footer-contact" className="mt-4 block text-sm text-accent underline-offset-4 hover:underline">Start an enquiry</Link></div>
    </div>
    <div className="border-t border-primary-foreground/15 px-5 py-5 md:px-8 lg:px-12"><div className="mx-auto flex max-w-[1400px] flex-col justify-between gap-2 text-[11px] text-primary-foreground/50 md:flex-row"><span>© 2026 HT Global Import Export Sdn. Bhd.</span><span className="mono-font">RELIABLE · SUSTAINABLE · GLOBAL</span></div></div>
  </footer>;
}

export function Shell({ children }: { children: ReactNode }) {
  return <div className="noise min-h-[100dvh]"><Header />{children}<Footer /></div>;
}

export function Breadcrumbs({ current }: { current: string }) {
  return <div className="mx-auto flex max-w-[1400px] items-center gap-2 px-5 pt-8 text-[11px] text-muted-foreground md:px-8 lg:px-12"><Link href="/" data-testid="link-breadcrumb-home" className="hover:text-primary">Home</Link><span>/</span><span className="text-foreground">{current}</span></div>;
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return <p className="eyebrow text-accent">{children}</p>;
}

export function ArrowLink({ href, children, light = false }: { href: string; children: ReactNode; light?: boolean }) {
  return <Link href={href} data-testid={`link-arrow-${String(children).toLowerCase().replace(/\s+/g, '-')}`} className={`group inline-flex items-center gap-2 text-sm font-semibold ${light ? 'text-primary-foreground' : 'text-primary'}`}><span className="border-b border-current pb-1">{children}</span><ArrowUpRight size={15} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" /></Link>;
}

export function QuantityControl({ value, onChange, testId }: { value: number; onChange: (value: number) => void; testId: string }) {
  return <div className="flex h-10 items-center border border-border">
    <button type="button" data-testid={`button-minus-${testId}`} onClick={() => onChange(Math.max(1, value - 1))} className="grid h-full w-9 place-items-center text-muted-foreground hover:text-primary"><Minus size={14} /></button>
    <span data-testid={`text-quantity-${testId}`} className="mono-font w-8 text-center text-xs">{value}</span>
    <button type="button" data-testid={`button-plus-${testId}`} onClick={() => onChange(value + 1)} className="grid h-full w-9 place-items-center text-muted-foreground hover:text-primary"><Plus size={14} /></button>
  </div>;
}

export const productImage = (id: string) => products.find((product) => product.id === id)?.image || '/images/plywood-stack.jpg';