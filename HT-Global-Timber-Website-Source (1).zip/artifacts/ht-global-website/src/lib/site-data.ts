export type ProductCategory =
  | 'Sawn Timber'
  | 'WBP Phenol Plywood'
  | 'LVL'
  | 'Veneer'
  | 'Furniture Panels'
  | 'Construction Materials'
  | 'Wooden Packaging';

export type Product = {
  id: string;
  name: string;
  category: ProductCategory;
  descriptor: string;
  description: string;
  image: string;
  specs: string[];
  units: string[];
  applications: string[];
  featured?: boolean;
};

export const products: Product[] = [
  {
    id: 'sawn-timber',
    name: 'Sawn Timber',
    category: 'Sawn Timber',
    descriptor: 'Prepared stock for structure, joinery and international supply.',
    description: 'Sawn timber selected and prepared for your end use, from structural stock to appearance-grade pieces. Species, dimensions, moisture content and packaging are aligned before shipment.',
    image: '/images/plywood-stack.jpg',
    specs: ['Species by request', 'Rough or surfaced', 'Kiln dried by requirement', 'Origin and grade confirmed per enquiry'],
    units: ['Cubic metres', 'Bundles', 'Containers'],
    applications: ['Construction', 'Joinery', 'Outdoor structures', 'Wooden packaging'],
    featured: true,
  },
  {
    id: 'wbp-phenol-plywood',
    name: 'WBP Phenol Plywood',
    category: 'WBP Phenol Plywood',
    descriptor: 'Water-resistant panels for formwork, construction and industrial use.',
    description: 'WBP phenol plywood for demanding applications where bond integrity, panel consistency and water resistance matter. Core, face/back, grade and sheet size are specified to the project.',
    image: '/images/factory-line.jpg',
    specs: ['1220 × 2440 mm or by request', '4–25 mm thickness', 'Core and face/back by specification', 'WBP phenol glue'],
    units: ['Sheets', 'Bundles', 'Containers'],
    applications: ['Construction', 'Formwork and shuttering', 'Marine applications', 'Furniture and industrial use'],
    featured: true,
  },
  {
    id: 'lvl',
    name: 'LVL',
    category: 'LVL',
    descriptor: 'Laminated veneer lumber for structural and industrial applications.',
    description: 'LVL made for buyers who need repeatable dimensions, reliable performance and a clear route from specification to shipment. Thickness, width, length, grade and application are agreed up front.',
    image: '/images/hero-timber.jpg',
    specs: ['Thickness, width and length by request', 'Species and grade confirmed per brief', 'Structural and packaging grades', 'Bundle or container packing'],
    units: ['Cubic metres', 'Pieces', 'Bundles'],
    applications: ['Construction beams', 'Structural components', 'Furniture', 'Industrial packaging'],
    featured: true,
  },
  {
    id: 'veneer',
    name: 'Veneer',
    category: 'Veneer',
    descriptor: 'Rotary-cut and sliced faces with the character of real timber.',
    description: 'Veneer for furniture, doors and architectural surfaces. We coordinate species, cut, grade, thickness and appearance requirements around the visual language of your project.',
    image: '/images/veneer-closeup.jpg',
    specs: ['Red Meranti, Yellow Meranti, Keruing and more', 'Rotary cut or sliced', 'Thickness and grade by request', 'Colour and appearance selected per brief'],
    units: ['Bundles', 'Packs', 'Square metres'],
    applications: ['Fine furniture', 'Doors and panels', 'Hospitality interiors', 'Retail environments'],
    featured: true,
  },
  {
    id: 'furniture-panels',
    name: 'Furniture Panels',
    category: 'Furniture Panels',
    descriptor: 'MR, MDF, HDMR, finger joint and blockboard panels.',
    description: 'Furniture panel ranges for manufacturing and interior applications, including MR, MDF, HDMR, finger joint, blockboard, hardwood panels, Falcata and PVC sheets.',
    image: '/images/plywood-stack.jpg',
    specs: ['MR, MDF, HDMR and blockboard options', 'Finger joint and hardwood panels', 'PVC sheet and Falcata available', 'Size, thickness and quantity by request'],
    units: ['Sheets', 'Bundles', 'Containers'],
    applications: ['Furniture manufacturing', 'Cabinetry', 'Interior fit-outs', 'Shopfitting'],
    featured: false,
  },
  {
    id: 'construction-materials',
    name: 'Construction Materials',
    category: 'Construction Materials',
    descriptor: 'Plywood, timber and panels for demanding building work.',
    description: 'Construction-related materials selected around the application, grade, dimensions and delivery requirement. Share the site use and we will help shape the right specification.',
    image: '/images/factory-line.jpg',
    specs: ['Product and application matched', 'Size and thickness by request', 'Grade and packaging confirmed', 'Bulk supply for projects'],
    units: ['Sheets', 'Cubic metres', 'Bundles', 'Containers'],
    applications: ['Formwork', 'Shuttering', 'Structural timber', 'Building materials'],
    featured: false,
  },
  {
    id: 'wooden-packaging',
    name: 'Wooden Packaging',
    category: 'Wooden Packaging',
    descriptor: 'Timber and plywood for crates, export and industrial packaging.',
    description: 'Packaging plywood, timber, crates and other wood packaging products for industrial and export use. Requirements are built around load, destination, treatment and packing method.',
    image: '/images/hero-timber.jpg',
    specs: ['Packaging plywood and timber', 'Crates and industrial packaging', 'Dimensions by drawing or brief', 'Treatment and documentation discussed per destination'],
    units: ['Pieces', 'Cubic metres', 'Bundles', 'Containers'],
    applications: ['Export packaging', 'Wooden crates', 'Industrial packaging', 'Pallet and dunnage needs'],
    featured: false,
  },
];

export const categories: { name: ProductCategory; count: string; copy: string }[] = [
  { name: 'Sawn Timber', count: '01 range', copy: 'Prepared stock for structure, joinery and packaging.' },
  { name: 'WBP Phenol Plywood', count: '01 range', copy: 'Water-resistant panels for construction and industrial use.' },
  { name: 'LVL', count: '01 range', copy: 'Laminated veneer lumber for structural applications.' },
  { name: 'Veneer', count: '01 range', copy: 'Natural surfaces where material character matters.' },
  { name: 'Furniture Panels', count: '01 range', copy: 'MR, MDF, HDMR and panel products for manufacturing.' },
  { name: 'Construction Materials', count: '01 range', copy: 'Plywood, timber and panels for building work.' },
  { name: 'Wooden Packaging', count: '01 range', copy: 'Timber and plywood for export and industrial packaging.' },
];

export const navItems = [
  { label: 'Home', href: '/' },
  { label: 'About Us', href: '/about' },
  { label: 'Shop', href: '/shop' },
  { label: 'Products', href: '/products' },
  { label: 'Industries', href: '/industries' },
  { label: 'Certifications', href: '/certifications' },
  { label: 'Contact Us', href: '/contact' },
];

export function getProduct(id: string) {
  return products.find((product) => product.id === id);
}