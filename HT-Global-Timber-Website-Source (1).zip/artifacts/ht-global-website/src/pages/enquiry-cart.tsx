import { useState, type FormEvent } from 'react';
import { ArrowUpRight, Check, Trash2 } from 'lucide-react';
import { Link } from 'wouter';
import { submitEnquiry } from '@workspace/api-client-react';
import { Breadcrumbs, QuantityControl, SectionLabel, useEnquiry, productImage } from '@/components/site-shell';
import { getProduct } from '@/lib/site-data';

export function EnquiryCart() {
  const { items, updateItem, removeItem, clearItems } = useEnquiry();
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    country: '',
    destination: '',
    deliveryDate: '',
    requirements: '',
    notes: '',
    consent: false,
  });
  const updateForm = (field: keyof typeof form, value: string | boolean) =>
    setForm((current) => ({ ...current, [field]: value }));

  if (submitted) {
    return <main><section className="mx-auto flex min-h-[620px] max-w-2xl flex-col justify-center px-5 py-20 text-center md:py-28">
      <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-accent text-accent-foreground"><Check size={28} /></span>
      <SectionLabel>Enquiry prepared</SectionLabel>
      <h1 className="display-font mt-5 text-5xl leading-tight text-primary">A clear next step.</h1>
      <p className="mx-auto mt-5 max-w-md text-base leading-7 text-muted-foreground">Thank you for your enquiry. Our sales team will review the full request and contact you shortly at {form.email}.</p>
      <Link href="/products" data-testid="link-confirmation-products" className="mx-auto mt-8 inline-flex items-center gap-3 bg-primary px-5 py-3.5 text-sm font-semibold text-primary-foreground">Continue browsing <ArrowUpRight size={16} /></Link>
    </section></main>;
  }

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    try {
      await submitEnquiry({
        ...form,
        deliveryDate: form.deliveryDate || null,
        items: items.map((item) => {
          const product = getProduct(item.productId);
          return { productId: item.productId, productName: product?.name ?? item.productId, quantity: item.quantity, unit: item.unit };
        }),
      });
      setSubmitted(true);
    } catch {
      setError('We could not send the enquiry. Please try again or contact us directly by email or WhatsApp.');
    }
  };

  return <main><Breadcrumbs current="Enquiry list" /><section className="mx-auto max-w-[1400px] px-5 pb-20 pt-12 md:px-8 md:pb-28 md:pt-20 lg:px-12">
    <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end"><div><SectionLabel>Request list</SectionLabel><h1 className="display-font mt-5 text-5xl leading-[1.04] text-primary md:text-7xl">Your material shortlist.</h1><p className="mt-6 max-w-xl text-base leading-7 text-muted-foreground">Adjust the quantities, choose a unit and send the full list to our trade desk. This is a request for quotation — there is no payment or checkout.</p></div>{items.length > 0 && <button type="button" data-testid="button-clear-enquiry" onClick={clearItems} className="inline-flex items-center gap-2 self-start text-xs font-semibold text-muted-foreground underline underline-offset-4 hover:text-destructive md:self-end">Clear list <Trash2 size={14} /></button>}</div>
    {items.length === 0 ? <div className="mt-16 border border-dashed border-border bg-card px-6 py-20 text-center"><p className="display-font text-4xl text-primary">Nothing shortlisted yet.</p><p className="mx-auto mt-4 max-w-sm text-sm leading-7 text-muted-foreground">Add products from the catalogue and they will appear here for one combined enquiry.</p><Link href="/products" data-testid="link-empty-products" className="mt-7 inline-flex items-center gap-2 border border-primary px-4 py-3 text-sm font-semibold text-primary">Browse the catalogue <ArrowUpRight size={15} /></Link></div> : <div className="mt-14 grid gap-12 lg:grid-cols-7">
      <div className="lg:col-span-4">{items.map((item) => { const product = getProduct(item.productId); if (!product) return null; return <div key={item.productId} className="flex gap-4 border-t border-border py-6"><img src={productImage(item.productId)} alt={product.name} className="h-24 w-28 object-cover sm:h-28 sm:w-36" /><div className="min-w-0 flex-1"><div className="flex justify-between gap-3"><div><span className="eyebrow text-accent">{product.category}</span><h2 className="display-font mt-1 text-2xl text-primary">{product.name}</h2></div><button type="button" data-testid={`button-remove-${item.productId}`} onClick={() => removeItem(item.productId)} aria-label={`Remove ${product.name}`} className="text-muted-foreground hover:text-destructive"><Trash2 size={16} /></button></div><div className="mt-5 flex flex-wrap items-center gap-5"><QuantityControl value={item.quantity} onChange={(value) => updateItem(item.productId, value, item.unit)} testId={item.productId} /><label className="flex h-10 items-center border border-border px-3"><span className="mr-3 text-[10px] uppercase tracking-widest text-muted-foreground">Unit</span><select value={item.unit} onChange={(event) => updateItem(item.productId, item.quantity, event.target.value)} data-testid={`select-unit-${item.productId}`} className="bg-transparent text-xs font-semibold outline-none">{product.units.map((unit) => <option key={unit}>{unit}</option>)}</select></label></div></div></div>; })}</div>
       <form onSubmit={handleSubmit} className="bg-primary p-6 text-primary-foreground md:p-8 lg:col-span-3"><p className="eyebrow text-accent">Request a quotation</p><h2 className="display-font mt-4 text-3xl">Send the full requirement.</h2><div className="mt-8 grid gap-4">
        <label className="grid gap-2 text-xs font-semibold">Full name<input required value={form.name} onChange={(event) => updateForm('name', event.target.value)} data-testid="input-enquiry-name" className="h-11 border border-primary-foreground/25 bg-primary-foreground/10 px-3 text-sm font-normal outline-none placeholder:text-primary-foreground/45 focus:border-accent" placeholder="Your name" /></label>
        <label className="grid gap-2 text-xs font-semibold">Company name<input required value={form.company} onChange={(event) => updateForm('company', event.target.value)} data-testid="input-enquiry-company" className="h-11 border border-primary-foreground/25 bg-primary-foreground/10 px-3 text-sm font-normal outline-none placeholder:text-primary-foreground/45 focus:border-accent" placeholder="Company name" /></label>
        <label className="grid gap-2 text-xs font-semibold">Work email<input required type="email" value={form.email} onChange={(event) => updateForm('email', event.target.value)} data-testid="input-enquiry-email" className="h-11 border border-primary-foreground/25 bg-primary-foreground/10 px-3 text-sm font-normal outline-none placeholder:text-primary-foreground/45 focus:border-accent" placeholder="name@company.com" /></label>
        <label className="grid gap-2 text-xs font-semibold">Phone / WhatsApp<input required value={form.phone} onChange={(event) => updateForm('phone', event.target.value)} data-testid="input-enquiry-phone" className="h-11 border border-primary-foreground/25 bg-primary-foreground/10 px-3 text-sm font-normal outline-none placeholder:text-primary-foreground/45 focus:border-accent" placeholder="+00 000 000 000" /></label>
        <div className="grid gap-4 sm:grid-cols-2"><label className="grid gap-2 text-xs font-semibold">Country<input required value={form.country} onChange={(event) => updateForm('country', event.target.value)} data-testid="input-enquiry-country" className="h-11 border border-primary-foreground/25 bg-primary-foreground/10 px-3 text-sm font-normal outline-none placeholder:text-primary-foreground/45 focus:border-accent" placeholder="Country" /></label><label className="grid gap-2 text-xs font-semibold">Delivery location / port<input required value={form.destination} onChange={(event) => updateForm('destination', event.target.value)} data-testid="input-enquiry-destination" className="h-11 border border-primary-foreground/25 bg-primary-foreground/10 px-3 text-sm font-normal outline-none placeholder:text-primary-foreground/45 focus:border-accent" placeholder="Port or city" /></label></div>
        <label className="grid gap-2 text-xs font-semibold">Preferred delivery date<input type="date" value={form.deliveryDate} onChange={(event) => updateForm('deliveryDate', event.target.value)} data-testid="input-enquiry-delivery-date" className="h-11 border border-primary-foreground/25 bg-primary-foreground/10 px-3 text-sm font-normal outline-none focus:border-accent" /></label>
        <label className="grid gap-2 text-xs font-semibold">Product requirements<textarea required value={form.requirements} onChange={(event) => updateForm('requirements', event.target.value)} data-testid="input-enquiry-requirements" rows={3} className="resize-none border border-primary-foreground/25 bg-primary-foreground/10 p-3 text-sm font-normal outline-none placeholder:text-primary-foreground/45 focus:border-accent" placeholder="Species, grade, dimensions, application..." /></label>
        <label className="grid gap-2 text-xs font-semibold">Additional requirements<textarea value={form.notes} onChange={(event) => updateForm('notes', event.target.value)} data-testid="input-enquiry-notes" rows={3} className="resize-none border border-primary-foreground/25 bg-primary-foreground/10 p-3 text-sm font-normal outline-none placeholder:text-primary-foreground/45 focus:border-accent" placeholder="Incoterms, packing, timing..." /></label>
        <label className="flex items-start gap-3 text-xs leading-5 text-primary-foreground/75"><input required type="checkbox" checked={form.consent} onChange={(event) => updateForm('consent', event.target.checked)} data-testid="checkbox-enquiry-consent" className="mt-1 accent-accent" />I agree that HT Global Import Export Sdn. Bhd. may contact me regarding this enquiry.</label>
       </div>{error && <p role="alert" className="mt-4 text-xs leading-5 text-red-200">{error}</p>}<button type="submit" data-testid="button-submit-enquiry" className="mt-6 inline-flex w-full items-center justify-center gap-2 bg-accent px-4 py-3.5 text-sm font-semibold text-accent-foreground">Request quotation <ArrowUpRight size={16} /></button><p className="mt-4 text-center text-[11px] leading-5 text-primary-foreground/50">We will reply with availability, specification details and next steps.</p></form>
    </div>}
  </section></main>;
}